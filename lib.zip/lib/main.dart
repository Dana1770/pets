import 'package:firebase_core/firebase_core.dart';
import 'package:first/modules/birds/birds.dart';
import 'package:first/modules/buffalo/buffalo.dart';
import 'package:first/modules/camels/camels.dart';
import 'package:first/modules/cats/cats.dart';
import 'package:first/modules/chameleon/Chameleon.dart';
import 'package:first/modules/chimps/chimps.dart';
import 'package:first/modules/cows/cows.dart';
import 'package:first/modules/crocodiles/Crocodiles.dart';
import 'package:first/modules/deers/deers.dart';
import 'package:first/modules/flamingos/Flamingos.dart';
import 'package:first/modules/fox/fox.dart';
import 'package:first/modules/frogs/frogs.dart';
import 'package:first/modules/gorella/gorilla.dart';
import 'package:first/modules/large_animals/Large_animals.dart';
import 'package:first/modules/profile/profilePage.dart';
import 'package:first/modules/sign%20up/sign%20up.dart';
import 'package:first/modules/small_animal/small_animal.dart';
import 'package:first/modules/whales/whales.dart';
import 'package:first/modules/wolf/wolf.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'modules/PETS_OR_LARGE/PETS_OR_LARGE.dart';


void main()async{
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
      home:SignUP()));
}

