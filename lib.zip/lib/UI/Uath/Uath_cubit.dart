import 'dart:ffi';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:first/UI/Uath/Uath_states.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
class Auth_cubit extends Cubit <Auth_state>{
Auth_cubit():super(InitialAppStates());
void sign_up ({required String email,required String password})async{
  try {
    UserCredential usercredential = await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password);
    if(usercredential.user?.uid !=null)
    {
      debugPrint("user cretaed successfully with uid :${usercredential.user!.uid}");
      emit(UserCreateSuccessState());
    }
/*  else {
  debugPrint("Failed to create user .......");
  emit(FailedToCrateUser());
  }*/
  }
  on FirebaseAuthException catch(e){
    debugPrint("Failed to register ,reason is :${e.code}");
    if(e.code=="")
    emit(FailedToCrateUser());

  }


}
}