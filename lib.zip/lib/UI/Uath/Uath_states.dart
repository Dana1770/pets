abstract class Auth_state {}
class InitialAppStates extends Auth_state{}
class UserCreateSuccessState extends Auth_state{}
class FailedToCrateUser extends Auth_state{}