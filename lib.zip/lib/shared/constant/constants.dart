import 'package:flutter/material.dart';

Color mainColor = Color(0xFF177767);

var containerRadius = Radius.circular(50);